"""
Presentation selection/composition

"""