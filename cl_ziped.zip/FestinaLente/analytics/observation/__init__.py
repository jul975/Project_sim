"""
Raw observed data types
"""